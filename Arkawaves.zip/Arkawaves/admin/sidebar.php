<style>
	

*{
	margin: 0;
	padding: 0;
	box-sizing: border-box;
	list-style: none;
	text-decoration: none;
	
}
body{
	background: #f3f5f9;
}
.wrapper{
	position: relative;
}
.sidebar{
	position: fixed;
	width: 250px;
	height: 100%;
	background: rgb(0, 132, 255);
	padding: 20px 0;
	
}
.text-muted{
	color: #adb5bd!important;
}

ul li a img{
	background: #66BB6A;
	top: 0;
	border: none;
	width: 20px;
}
 .sidebar ul li{
	padding: 15px;
	transition: .2s ease-in-out;

}
.sidebar ul li a{
	margin-left:  10px;	
	color: #fff;
	display: block;
}
.sidebar ul li a .fas,ul li a .far  {
	width: 30px;
	color: #fff!important;
}
i.fas.fa-home:hover,
i.fas.fa-file-invoice:hover,
i.fas.fa-video:hover,
i.fas.fa-id-badge:hover,
i.fas.fa-external-link-alt:hover,
i.fas.fa-code:hover,
i.far.fa-calendar-alt:hover,
i.far.fa-credit-card:hover{
	/*color: #304FFE!important;*/
} 
.sidebar ul li a .far{
	width: 30px;
	color: #1b3cfd!important;
}
.sidebar ul li:hover{
	background: #3D59FF;
}
.sidebar ul li a:hover{
	text-decoration: none;
}
	
.sb-small {
	margin-left:  5px;
	color:  #fff;
	font-weight:  bold;
}




</style>
<div class="wrapper d-flex">
	<div class="sidebar" style="margin-top: 60px;">
		<small class="pl-3 sb-small">MAIN</small>
		<ul >
			<li><a href="#"><i class="fas fa-home"></i>Dashboard</a></li>
			<li><a href="#"><i class="fas fa-shopping-cart"></i>POS</a></li>
			<li><a href="#"><i class="fas fa-list"></i>Monitoring</a></li>
			<li><a href="#"><i class="fas fa-print"></i>Report</a></li>
		</ul>
		<small class="pl-3 sb-small">MANAGE</small>
		<ul>
			<li><a href="credentials.php"><i class="fas fa-calendar-alt"></i>Credentials</a></li>
			<li><a href="#"><i class="fas fa-id-badge"></i>Public Profile</a></li>
		</ul>
		
	</div>
</div>