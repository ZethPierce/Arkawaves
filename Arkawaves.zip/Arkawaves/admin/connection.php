<?php 
   $conn = mysqli_connect("localhost", "root", "", "arkawaves_db");
                 
?>