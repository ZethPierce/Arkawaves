<link rel="stylesheet" type="text/css" href="../css/sidebar.css">
<div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
               
                 <li class="sidebar-brand">
                    <a href="#">
                        MANAGE
                    </a> 
                </li>
                <li>
                    <a href="#"><i class="fa fa-users"></i> &nbsp; Total Borrowed</a>
                </li>
                <li>
                    <a href="#"><i class="fas fa-user"></i> &nbsp; User Profile</a>
                </li>
                
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

      
        <!-- /#page-content-wrapper -->

 
 <!--<script src="../js/sidebar.js"></script> -->
  