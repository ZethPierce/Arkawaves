<?php
include('connection.php');
include('tags.php');
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Arkawaves Purified Refilling Station </title>

    <style>
          .panel{
               color:  white;
               height:  100px;
               margin-left: -10px;
               margin-right: -10px;
               font-size:  1.8rem;
               font-weight:  bolder;
          }
          .panelcolor1{
              /* background: rgb(80, 143, 244); */
               background:  rgb(255 106 106);
              border-color:  rgb(255 106 106);
          }
          .panelcolor2{
               background: rgb(146, 103, 255);
               border-color:  rgb(146, 103, 255);
          }
          .panelcolor3{
               background: rgb(26 215 163);
               border-color: rgb(26 215 163);     
          }
          .panelcolor4{
               background: rgb(255 158 101);
               border-color: rgb(255 158 101);
          }



     </style>

</head>

<body>
<!-- Navigation -->
<?php 
	include('header.php');
	include('sidebar.php');
?>
&nbsp;<a href="#menu-toggle" class="btn btn-default" id="menu-toggle" style="margin-top: 80px;"><i class=" fas fa-align-justify"></i></a>

<div id="page-content-wrapper" >
    <div class="container-fluid" >
        <div class="row">
            <div class="col-lg-3">
                 <div class="panel panel-default panelcolor1">
                      <!--<div class="panel-heading">Panel with panel-default class</div> -->
                      <div class="panel-body bg-black ">SALES</div>
                </div>
            </div>
            <div class="col-lg-3">
                 <div class="panel panel-default panelcolor2">                    
                      <div class="panel-body">CUSTOMERS</div>
                 </div>
            </div>
            <div class="col-lg-3">
                 <div class="panel panel-default panelcolor3">                     
                      <div class="panel-body">UNPAID</div>
                 </div>
            </div>
            <div class="col-lg-3">
                 <div class="panel panel-default panelcolor4">                     
                      <div class="panel-body">EXPENSES</div>
                </div>
            </div>
               <table class='table table-bordered table-striped'>
                      <tr style="background: #d9d9d9 !important; text-align: center;">
                        <th>ID</th>
                        <th>Item</th>
                        <th>Quantity</th>
                        <th>Date</th>
                                                                          
                      </tr>                    
                      <tr>
                        <td>1</td>
                        <td>Gallon - Slim</td>
                        <td>1</td>
                        <td>July 21, 2020</td>                                         
                      
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Gallon - Slim</td>
                        <td>5</td>
                        <td>May 08, 2020</td>                                         
                      
                    <tr>
                        <td>3</td>  
                        <td>Gallon - Round</td>
                        <td>5</td>
                        <td>May 25, 2020</td>                                         
                      
                    </tr>
               </table>      








        </div>
    </div>
</div>


</body>

</html>
 <script src="../js/sidebar.js"></script>