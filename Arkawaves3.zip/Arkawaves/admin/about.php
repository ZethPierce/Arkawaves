<?php
include('connection.php');
include('tags.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href='admin.css' rel='stylesheet' />
    <title>Immunization Management System</title>
</head>
<style>
    .abt-color{
        color: rgb(0, 132, 255);
    }
</style>
<body>

    <!-- Navigation -->
	<?php 
		include('header.php');
	?>

    <!-- Page Content -->
    <div class="container fontStyle">
        <div class="content-wrapper">
		<center>
            <div class="row" style="max-width: 1500px;">
                <div class="">
                    <p>
                    <h1 class="font arrange-content left-pad abt-color"><span style="color: black;"></span> <br/> <b>ABOUT US</b></h1>
                    </p>
                    <p class="description left-pad abt-color">Arkawaves Purified Refilling Station was established on November 15, 2021 by Mrs. Geraldine Fortunado located at Blk21 L2 Everlasting St. Queensrow West, Bacoor. Arkawaves owner, Geraldine Fortunado is a successful woman and a loving mother and wife to her husband and children. Their water station services are catered to meet the needs of their customers both as an individual and as a business.</p>
                  
                </div>
                
            </div>
			</center>
        </div>
    </div>

</body>

</html>
