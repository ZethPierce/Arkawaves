<link rel="stylesheet" type="text/css" href="../css/sidebar.css">
<div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                        MAIN
                    </a> 
                </li>
                <li>
                    <a href="dashboard.php"><i class="fab fa-microsoft"></i> &nbsp; Dashboard</a>
                </li>
                <li>
                    <a href="pos.php"><i class="fas fa-shopping-cart"></i> &nbsp; POS</a>
                </li>
                <li>
                    <a href="#"><i class="fas fa-align-justify"></i> &nbsp; Monitoring</a>
                </li>
                <li>
                    <a href="#"><i class="fas fa-home"></i> &nbsp; Report</a>
                </li>
                <li>
                    <a href="#"><i class="fas fa-print"></i> &nbsp; Print</a>
                </li>

                 <li class="sidebar-brand">
                    <a href="#">
                        MANAGE
                    </a> 
                </li>
                <li>
                    <a href="credentials.php"><i class="fa fa-users"></i> &nbsp; Credentials</a>
                </li>
                <li>
                    <a href="#"><i class="fas fa-user"></i> &nbsp; User Profile</a>
                </li>
                
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

      
        <!-- /#page-content-wrapper -->

 
 <!--<script src="../js/sidebar.js"></script> -->
  