<?php
include('connection.php');
include('tags.php');
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Arkawaves Purified Refilling Station </title>

    <style>


.heading {
	padding: 0px;
	margin-top: 0px;
}

.home {
	margin-left: 71px;
}

.navbar-header.logo {
	margin-top: 30px;
}


a:hover {
	color: #00a82d;
}




.btn-default {
	color: #333;
	background-color: #fff;
}

.log-btn {
	margin-right: 50px;
	margin-left: 20px;
	width: 121px;
	border: solid green 2px;
	color: blue;
}

.font {
	
	display: block;
	font-size: 56px;
	line-height: 72px;
	color: rgb(0, 132, 255);
}

.description {
	
	font-size: 20px;
	line-height: 40px;
	margin-bottom: 35px;
	color: black;
	font-weight: 20;
}

.arrange-content {
	padding-top: 128px;
}

.left-pad {
	padding-left: 65px;
}

.laptop {
	width: 91.7%;
}

.image {
	display: inline-block;
}

.design {
	width: 242px;
	height: 57px;
	font-weight: bold;
	border-radius: 50px;
	transition: .3s ease-in-out;
	background: blue;
	color: white;
}
.design:hover{
	background: darkblue;
	color: white;

}

.index-btn{
	width: 242px; height: 57px; font-weight: bold; border-radius: 50px; 
	transition: .3s ease-in-out; background: rgb(0, 132, 255);; color: white;
}
.index-btn:hover{
	background: #3D59FF;
	color: white;
}




@media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (-webkit-min-device-pixel-ratio: 2) {
	.font {
		font-family: 'Lato', sans-serif;
		display: block;
		font-size: 25px;
		line-height: 36px;
		color: white;
	}
	.laptop {
		display: none;
	}
}
</style>

</head>

<body>

    <!-- Navigation -->
	<?php 
		include('header.php');
	?>

    <!-- Page Content -->
    <div class="container-fluid fontStyle">
        <div class="content-wrapper">
		<center>
            <div class="row" style="max-width: 1500px;">
                <div class="col-md-6 col-lg-6 text-left">
                    <p>
                    <h1 class="font arrange-content left-pad"><span style="color: black;">Welcome to</span> <br/> <b>Arkawaves Purified Refilling Station </b></h1>
                    </p>
                    <p class="description left-pad"> A Safe and Healthy drinking water for everyone.</p>
                    <div class="left-pad">
						<a href="registration.php">
							<button type="button" class=" btn index-btn">
								GET STARTED
							</button>
						</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 text-left ">
                    <img  src="../img/waterbg3.png"  class="hidden-xs hidden-sm laptop arrange-content" alt="evernote image" >
                </div>
            </div>
			</center>
        </div>
    </div>

</body>

</html>
