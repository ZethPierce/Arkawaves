<?php
include('connection.php');
include('tags.php');
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Arkawaves Purified Refilling Station </title>
</head>
<style>
    .well{
        background: inherit;
    }
</style>

<body>
<!-- Navigation -->
<?php 
	include('header.php');
	include('sidebar.php');
?>
&nbsp;<a href="#menu-toggle" class="btn btn-default" id="menu-toggle" style="margin-top: 80px;"><i class=" fas fa-align-justify"></i></a>

<div id="page-content-wrapper" >
    <div class="container-fluid" >
        <div class="row">
            <i class="fas fa-shopping-cart"></i> Point Of Sale &nbsp;
            <button class="btn btn-primary btnclr2" >
                <i class="fas fa-search"></i> Customer
            </button>

            <button class="btn btn-primary btnclr1">
                <i class="glyphicon glyphicon-refresh"></i> Return Gallon
            </button>

            <button class="btn btn-primary btnclr4" data-toggle="modal" data-target="#newCustomerModal">
                <i class="fas fa-plus"></i> New Customer
            </button>
        </div>
        <br>
        <div class="row">           
             <div class="col-sm-8">
                 <div class="well">
                  <h4>Column 1</h4>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
                  <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
              </div>
            </div>
            <div class="col-sm-4 ">
                <div class="well">
                  <h4 class="">Date: 
                    <?php 
                        $d=strtotime("tomorrow");
                        echo "<div style='float: right;'>".date("Y-m-d") . "</div><br>";?>               
                  </h4>
                  <h4 class="text-center"><small>Order Item Summary.</small></h4>
                  <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
                </div>
            </div>          
        </div>
    </div>
</div>

<div class="modal fade" id="newCustomerModal" role="dialog">
    <div class="modal-dialog modal-lg">   
      <!-- Modal content-->
        <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Customer</h4>
                </div>
                <div class="modal-body">                   
                    <form action="/action_page.php">

                        <div class="row">  
                            <div class="col-sm-4">                          
                                  <div class="form-group">
                                        <label for="email">Last Name:</label>
                                        <input type="text" class="form-control" id="last_name">
                                  </div>
                            </div>
                            <div class="col-sm-4">                          
                                  <div class="form-group">
                                        <label for="email">First Name:</label>
                                        <input type="text" class="form-control" id="first_name">
                                  </div>
                            </div>
                            <div class="col-sm-4">                          
                                  <div class="form-group">
                                    <label for="gender">Gender:</label>
                                       <select class="form-control" name="gender">
                                           <option selected disabled>Select a Gender</option>
                                           <option value="Male">Male</option>
                                           <option value="Female">Female</option>
                                       </select>
                                  </div>
                            </div>
                         </div>

                         <div class="row">
                            <div class="col-sm-8">                          
                                  <div class="form-group">
                                        <label for="email">Alias/Comments:</label>
                                        <input type="text" class="form-control" id="comments">
                                  </div>
                            </div>
                            <div class="col-sm-4">                          
                                  <div class="form-group">
                                        <label for="email">Email:</label>
                                        <input type="text" class="form-control" id="email">
                                  </div>
                            </div>
                         </div>

                         <div class="row">
                            <div class="col-sm-4">                          
                                  <div class="form-group">
                                        <label for="email">Date of Birth:</label>
                                        <input type="date" class="form-control" id="comments">
                                  </div>
                            </div>
                            <div class="col-sm-4">                          
                                  <div class="form-group">
                                        <label for="email">Mobile 1:</label>
                                        <input type="text" class="form-control" id="mobile1">
                                  </div>
                            </div>
                             <div class="col-sm-4">                          
                                  <div class="form-group">
                                        <label for="email">Mobile 2:</label>
                                        <input type="text" class="form-control" id="mobile2">
                                  </div>
                            </div>
                         </div>

                         <div class="row">
                            <div class="col-sm-4">                          
                                  <div class="form-group">
                                        <label for="email">House No.</label>
                                        <input type="date" class="form-control" id="house_no">
                                  </div>
                            </div>
                            <div class="col-sm-4">                          
                                  <div class="form-group">
                                        <label for="email">Street:</label>
                                        <input type="text" class="form-control" id="street">
                                  </div>
                            </div>
                             <div class="col-sm-4">                          
                                  <div class="form-group">
                                        <label for="gender">Barangay:</label>
                                        <select class="form-control" name="gender">
                                           <option selected disabled>Select a Barangay</option>
                                           <option value="Male">Male</option>
                                           <option value="Female">Female</option>
                                        </select>
                                  </div>
                            </div>
                         </div>

                          <div class="row">
                            <div class="col-sm-6">                          
                                  <div class="form-group">
                                        <label for="email">City:</label>
                                        <input type="text" class="form-control" id="city">
                                  </div>
                            </div>
                            <div class="col-sm-6">                          
                                  <div class="form-group">
                                        <label for="email">Province:</label>
                                        <input type="text" class="form-control" id="province">
                                  </div>
                            </div>                          
                         </div>

                        <div class="row">
                            <table class='table table-bordered table-striped'>
                                <tr style="background: #d9d9d9 !important; text-align: center;">
                                    <th>#</th>
                                    <th>Item</th>
                                    <th>Client Gallon</th>
                                    <th>WRS Gallon</th>
                                    <th>Quantity</th>                                                             
                                </tr>                    
                                <tr>
                                    <td>1</td>
                                    <td><img src="../img/product1.jpg" width="30">500 ML Bottle Water</td>
                                    <td><input type="text" size="5"/></td>    
                                    <td><input type="text" size="5"/></td>
                                    <td></td>    
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td><img src="../img/product2.jpg" width="30">5 Liter Gallon</td>
                                    <td><input type="text" size="5"/></td>    
                                    <td><input type="text" size="5"/></td>
                                    <td></td>    
                                </tr>
                                 <tr>
                                    <td>3</td>
                                    <td><img src="../img/product3.jpg" width="30">5 Liter Round Gallon</td>
                                    <td><input type="text" size="5"/></td>    
                                    <td><input type="text" size="5"/></td>
                                    <td></td>    
                                </tr>
                            </table>               
                         </div>
                                  
                </div>
                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary float-right" >Save</button>
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </form>    
        </div>     
    </div>
</div>





</body>

</html>
 <script src="../js/sidebar.js"></script>