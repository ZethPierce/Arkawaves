<?php
include('connection.php');
include('tags.php');
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Arkawaves Purified Refilling Station </title>

    <style>
         


     </style>

</head>

<body>
<!-- Navigation -->
<?php 
	include('header.php');
	include('sidebar.php');
?>
&nbsp;<a href="#menu-toggle" class="btn btn-default" id="menu-toggle" style="margin-top: 80px;"><i class=" fas fa-align-justify"></i></a>

<div id="page-content-wrapper" >
    <div class="container-fluid" >
        <div class="row">
            <div class="col-lg-3">
                 <div class="panel panel-default panelcolor1">
                      <!--<div class="panel-heading">Panel with panel-default class</div> -->
                      <div class="panel-body bg-black ">SALES</div>
                </div>
            </div>
            <div class="col-lg-3">
                 <div class="panel panel-default panelcolor2">                    
                      <div class="panel-body">CUSTOMERS</div>
                 </div>
            </div>
            <div class="col-lg-3">
                 <div class="panel panel-default panelcolor3">                     
                      <div class="panel-body">UNPAID</div>
                 </div>
            </div>
            <div class="col-lg-3">
                 <div class="panel panel-default panelcolor4">                     
                      <div class="panel-body">EXPENSES</div>
                </div>
            </div>
               <table class='table table-bordered table-striped'>
                      <tr style="background: #d9d9d9 !important; text-align: center;">
                        <th>ID</th>
                        <th>NAME</th>
                        <th>Address</th>
                        <th>Added By</th>
                        <th>Date</th>
                        <th>Edit</th> 
                        <th>Delete</th>                                                               
                      </tr>                    
                      <tr>
                        <td>1</td>
                        <td>Juan Dela Cruz</td>
                        <td>24 Victoria st. Quezon City</td>    
                        <td>mainadmin</td>
                        <td>July 21, 2020</td>                                         
                       <td><?php echo '<button class="btn btn-warning editBtn" data-toggle="modal" data-target="#editBtn">Edit</button>' ?> </td> 
                       <td><?php echo '<button class="btn btn-danger deleteAdmin" data-toggle="modal" data-target="#deleteAdmin">Delete</button>' ?> </td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Maria San Juan</td>
                        <td>166 Martinez st. Quezon City</td>    
                        <td>mainadmin</td>
                        <td>May 08, 2020</td>                                         
                       <td><?php echo '<button class="btn btn-warning editBtn" data-toggle="modal" data-target="#editBtn">Edit</button>' ?> </td> 
                       <td><?php echo '<button class="btn btn-danger deleteAdmin" data-toggle="modal" data-target="#deleteAdmin">Delete</button>' ?> </td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Michael Francis Santos</td>
                        <td>1094 Pag Asa st. Pasig City</td>    
                        <td>mainadmin</td>
                        <td>May 08, 2020</td>                                         
                       <td><?php echo '<button class="btn btn-warning editBtn" data-toggle="modal" data-target="#editBtn">Edit</button>' ?> </td> 
                       <td><?php echo '<button class="btn btn-danger deleteAdmin" data-toggle="modal" data-target="#deleteAdmin">Delete</button>' ?> </td>
                    </tr>
               </table>      








        </div>
    </div>
</div>


</body>

</html>
 <script src="../js/sidebar.js"></script>