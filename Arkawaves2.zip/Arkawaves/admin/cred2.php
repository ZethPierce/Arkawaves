<?php 
session_start();
include('tags.php');

include('connection.php');
?>


<head>
<style>
.row.text-center > div {
    display: inline-block;
    float: none;
}
</style>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Arkawaves Purified Refilling Station </title>
</head>
<body>
<?php include('header.php');
include('sidebar.php'); ?>

        <!-- page content area main -->
<div class="container fontStyle" >       
<br>
  <!-- <div class="row text-center">
    <div class="col-sm-4" style="margin-left: 50px;">
      <ul class="nav nav-pills ">
        <li class="active "><a data-toggle="pill" href="#home">Admin Credentials</a></li>
        <li><a data-toggle="pill" href="#menu1">User Credentials</a></li>
      </ul>
    </div>
  </div> -->




  <div class="row justify-content-center" style="margin-top: 100px;">

  <div class="tab-content">
    
    <div id="home" class="tab-pane fade in active">
    <center>     
      <h2>Manage Admin Credentials</h2>
      <br>
      <?php 
      $res = mysqli_query($conn, "SELECT * FROM tbl_admin_credentials order by ID desc");
      if($res){
        $rowcount = mysqli_num_rows($res);
      }
      
      ?>    
      
       <button class="btn btn-primary" style="float: left;" data-toggle="modal" data-target="#addAdmin">Add New Admin</button>        
      <br><br>
      <table class='table table-bordered table-striped'>
        <tr style="background: #d9d9d9 !important; text-align: center;">
          <th>ID</th>
          <th>Last Name</th>
          <th>First Name</th>
          <th>Middle Name</th>
          <th>Username</th>
          <th>Password</th>
         <th>Edit</th> 
          <th>Delete</th>                                                               
        </tr>
      <?php while($row = mysqli_fetch_array($res)){ ?>
        <tr>
          <td><?php echo $row["id"]; ?> </td>
          <td><?php echo $row["last_name"]; ?> </td>
          <td><?php echo $row["first_name"]; ?> </td>
          <td><?php echo $row["middle_name"]; ?> </td>           
          <td><?php echo $row["username"]; ?> </td>
          <td><?php echo $row["password"]; ?> </td>                     
         <td><?php echo '<button class="btn btn-warning editBtn" data-toggle="modal" data-target="#editBtn">Edit</button>' ?> </td> 
        
          <td><?php echo '<button class="btn btn-danger deleteAdmin" data-toggle="modal" data-target="#deleteAdmin">Delete</button>' ?> </td>
        </tr>
        <?php
        }
        ?>
      </table>
      
      </div>
      
  </center>









<!-- Close Tab 1 -->

<div id="menu1" class="tab-pane fade">
        <center>     
      <h2>Manage User Credentials</h2>
      <br>
      <?php 
      $res = mysqli_query($conn, "SELECT * FROM tbl_user_credentials order by ID desc");
      if($res){
        $rowcount = mysqli_num_rows($res);
      }
      
      ?>    
      
      <button class="btn btn-primary" style="float: left;" data-toggle="modal" data-target="#addBtnUser">Add New User</button>            
      <br><br>
      <table class='table table-bordered table-striped'>
        <tr style="background: #d9d9d9 !important; text-align: center;">
          <th>ID</th>
          <th>Last Name</th>
          <th>First Name</th>
          <th>Middle Name</th>
          <th>Username</th>
          <th>Password</th>
          <th>Email</th>
          <th>Contact Number</th>
          
      <!--     <th>Edit</th> -->
          <th>Delete</th>                                                               
        </tr>
      <?php while($row = mysqli_fetch_array($res)){ ?>
        <tr>
          <td><?php echo $row["id"]; ?> </td>
          <td><?php echo $row["last_name"]; ?> </td>
          <td><?php echo $row["first_name"]; ?> </td>
          <td><?php echo $row["middle_name"]; ?> </td>           
          <td><?php echo $row["username"]; ?> </td>
          <td><?php echo $row["password"]; ?> </td>
          <td><?php echo $row["email"]; ?> </td>
          <td><?php echo $row["contact_number"]; ?> </td>
                               
         <td><?php echo '<button class="btn btn-warning editBtn" data-toggle="modal" data-target="#editBtn">Edit</button>' ?> </td> 
        
          <td><?php echo '<button class="btn btn-danger deleteUser" data-toggle="modal" data-target="#deleteUser">Delete</button>' ?> </td>
        </tr>
        <?php
        }
        ?>
      </table>
      
      </div>
      
  </center>
        </div>
      </div>
  </div>
</div>

<!-- Add Modal -->
<div id="addAdmin" class="modal fade fontStyle" role="dialog" style="zoom: 90%;">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add New Admin</h4>
      </div>     

      <div class="modal-body">
        <form action="" method="post">  
          <div class="form-group">
            <label for="usr">Last Name:</label>
            <input type="text" name="last_name" class="form-control" required>
          </div>

          <div class="form-group">
            <label for="usr">First Name:</label>
            <input type="text" name="first_name" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="usr">Middle Name:</label>
            <input type="text" name="middle_name" class="form-control">
          </div>
          <div class="form-group">
            <label for="usr">Username:</label>
            <input type="text" name="username" class="form-control" required >
          </div>
          <div class="form-group">
            <label for="usr">Password:</label>
            <input type="password" name="password" class="form-control" required>
          </div>    
        </div>

        <div class="modal-footer">
          <button type="submit" name="addData" class="btn btn-primary">Add Admin</button>
          <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
        </div>
      </form>
    </div>
  </div>
</div>     
<!-- End of Add Modal --> 


<!-- Update Modal -->
<div id="editBtn" class="modal fade" role="">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Update User</h4>
      </div>     
      <div class="modal-body">
        <form action="" method="post">
          <input id="update_id" name="update_id" type="hidden">
       <div class="form-group">
            <label for="usr">Last Name:</label>
            <input type="text" name="last_name" id="last_name" class="form-control" required>
          </div>

          <div class="form-group">
            <label for="usr">First Name:</label>
            <input type="text" name="first_name" id="first_name" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="usr">Middle Name:</label>
            <input type="text" name="middle_name" id="middle_name" class="form-control">
          </div>
          <div class="form-group">
            <label for="usr">Username:</label>
            <input type="text" name="username" id="username" class="form-control" required >
          </div>
          <div class="form-group">
            <label for="usr">Password:</label>
            <input type="password" name="password" id="password" class="form-control" required>
          </div>    
        </div>
        <div class="modal-footer">
          <button type="submit" name="updateData" class="btn btn-primary">Update</button>
          <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
        </div>
      </form>
    </div>
  </div>
</div>     
<!-- End of Update Modal -->




<!-- Delete Modal -->
<div id="deleteAdmin" class="modal fade fontStyle" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Delete User</h4>
        </div>
      <form action="" method="post">
        <div class="modal-body">
          <input id="delete_id" name="delete_id" type="hidden">
          <p>Are you sure you want to delete this User?</p>
        </div>
        <div class="modal-footer">
          <button type="submit" name="deleteData" class="btn btn-danger">Delete</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>  
  </div>
</div>
<!-- ADD QUERY [ADD NEW USER] -->  
<?php 
  if(isset($_POST["addData"]))
     {
        $last_name = $_POST['last_name'];
        $first_name = $_POST['first_name'];
        $middle_name = $_POST['middle_name'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $query_show = mysqli_query($conn, "SELECT * FROM tbl_admin_credentials");
        
        $query = mysqli_query($conn, "SELECT * FROM tbl_admin_credentials WHERE username='$username'");
         if(mysqli_num_rows($query) > 0) 
         {
             echo '<div class="alert alert-danger fontStyle" style="width: 100% !important;">
             <center> The username you entered already exists.</center>
        </div>';
         }
         else 
         {
           // ones na lumagpas sa 3 yung magreregister sa kanya, i-aalert nya yung baba.
            if(mysqli_num_rows($query_show) > 3) 
            {
              echo '<div class="alert alert-danger fontStyle" style="width: 100% !important;">
                      <center>Sorry, you have reached the user account limit.</center>
                    </div>';
            }   
            else
            {
              //else, i-eexecute nya yung insert query
              $query_insert = mysqli_query($conn, "INSERT INTO tbl_admin_credentials 
                  VALUES('', '$last_name', '$first_name', '$middle_name', 
                  '$username', '$password')");
                if($query_insert)
                {            
                  echo '<script> window.location="credentials.php";</script>';  
                  /*
                echo ' <div class="alert alert-success fontStyle" style="width: 100% !important;">
                <center> Registration successfully </center>
                       </div>';
                       */
                }
            
            }
          }
      }

     if(isset($_POST['deleteData'])){    
        $id = $_POST['delete_id'];
        $query = mysqli_query($conn, "DELETE FROM tbl_admin_credentials WHERE id='$id'");
        if($query) {
          echo '<script> window.location="credentials.php";</script>';  
          /*
            echo '<div class="alert alert-success fontStyle" style="width: 100% !important;">
            <center>
               Successfully Deleted
            </center>
            </div>';
            */
        }
     }
?>  

<!-- End of Delete Modal -->
</body>
<script>
    $('.editBtn').on('click', function(){
          
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
          //      console.log(data);
            }).get();

            $('#update_id').val(data[0]);
            $('#last_name').val(data[1]);
            $('#first_name').val(data[2]);
            $('#middle_name').val(data[3]);
            $('#username').val(data[4]);
            $('#password').val(data[5]);
           
 });

    $(document).ready(function(){
        $('.deleteAdmin').on('click', function(){
            
         //   $('#deleteUser').modal('show');

       //     $('#deleteUser').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
      //          console.log(data);
            }).get();
            $('#delete_id').val(data[0]);          
        });
    });
</script>



