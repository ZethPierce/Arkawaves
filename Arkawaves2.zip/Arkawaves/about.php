<?php
include('connection.php');
include('tags.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href='css/admin.css' rel='stylesheet' />
    <title>R Limon Poultry</title>
</head>

<body>

    <!-- Navigation -->
	<?php 
		include('header.php');
	?>

    <!-- Page Content -->
    <div class="container fontStyle">
        <div class="content-wrapper">
		<center>
            <div class="row" style="max-width: 1500px;">
                <div class="">
                    <p>
                    <h1 class="font arrange-content left-pad"><span style="color: black;"></span> <br/> <b>ABOUT US</b></h1>
                    </p>
                    <p class="description left-pad"> R. Limon Poultry there are two branches the first branch was built on July 1, 2008, in Bayanan Muntinlupa, and the second branch was built on June 1, 2015, in Blk 21 Lot 26 Lotus st Ts Cruz Subdivision, The R.Limon Poultry sells dog food, Cat Food and feeds for cocks and the owner of the shop Mr.Ramon Limon.</p>
                  
                </div>
                
            </div>
			</center>
        </div>
    </div>

</body>

</html>
